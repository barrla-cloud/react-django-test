#!/usr/bin/env python
from django.apps import AppConfig


class DjangoCreateSuperUserConfig(AppConfig):
    name = 'django_createsuperuser'
